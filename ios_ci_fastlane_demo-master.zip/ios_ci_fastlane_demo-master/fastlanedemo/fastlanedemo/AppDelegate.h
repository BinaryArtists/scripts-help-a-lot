//
//  AppDelegate.h
//  fastlanedemo
//
//  Created by everettjf on 9/8/15.
//  Copyright (c) 2015 everettjf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

