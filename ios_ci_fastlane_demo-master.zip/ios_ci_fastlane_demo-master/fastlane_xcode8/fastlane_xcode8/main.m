//
//  main.m
//  fastlane_xcode8
//
//  Created by everettjf on 9/18/16.
//  Copyright © 2016 everettjf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
